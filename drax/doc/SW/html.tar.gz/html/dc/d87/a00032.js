var a00032 =
[
    [ "isca_data_queue_indexer", "d4/d6d/a00055.html", "d4/d6d/a00055" ],
    [ "queue_lock_acquire", "dc/d87/a00032.html#a9b154efe4bde406048cb21f60db6fc80", null ],
    [ "queue_lock_release", "dc/d87/a00032.html#a83413b2afd2851d06aaf12b134aea6d8", null ],
    [ "isca_queue_acquire", "dc/d87/a00032.html#aff967776ea1fcfc5d5cf76a6624b6ba4", null ],
    [ "isca_queue_release", "dc/d87/a00032.html#a9cdf2ab4c3573aa81caa707a07a5ace6", null ],
    [ "isca_queue_rd_ptr", "dc/d87/a00032.html#a59547509475e936083586463d4a4430d", null ],
    [ "isca_queue_wr_ptr", "dc/d87/a00032.html#ac487b0939de04c47e01c54342adde2e3", null ],
    [ "available_queues", "dc/d87/a00032.html#adc98f5268856cf648f863bb994e5777e", null ],
    [ "queue_slots", "dc/d87/a00032.html#a1cd30ca661f4222222b90f8ce9b2ba77", null ],
    [ "queue", "dc/d87/a00032.html#a5a6f0bdffdef16b2ce3cbd9aa2ef1011", null ]
];