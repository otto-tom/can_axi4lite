var a00055 =
[
    [ "rd_ptr", "d4/d6d/a00055.html#a0f65a7e98bd6c053845e4a3a2783a1fe", null ],
    [ "wr_ptr", "d4/d6d/a00055.html#a9bcf5c226a149868e35f98d9f375c103", null ]
];