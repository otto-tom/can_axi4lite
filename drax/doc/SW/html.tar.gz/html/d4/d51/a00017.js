var a00017 =
[
    [ "MAX_QUEUES", "d4/d51/a00017.html#a16d3fa04757c66ba1c3228f57e1be03d", null ],
    [ "DQ_OK", "d4/d51/a00017.html#aa99fb78671a7d1bf2773d2b47a0f4629", null ],
    [ "DQ_AVAILABLE", "d4/d51/a00017.html#a2f1b4900e6b5cd6348e888e52ef5a0e4", null ],
    [ "DQ_OCCUPIED", "d4/d51/a00017.html#ad4191f59c3303b69ac6e62d406de8135", null ],
    [ "DQ_FULL", "d4/d51/a00017.html#a170dfeeaf5ab899d47a375408c3dc82d", null ],
    [ "DQ_EMPTY", "d4/d51/a00017.html#a29e14abfe1351d97d8216ba3c42e325f", null ],
    [ "isca_queue_acquire", "d4/d51/a00017.html#aff967776ea1fcfc5d5cf76a6624b6ba4", null ],
    [ "isca_queue_release", "d4/d51/a00017.html#a9cdf2ab4c3573aa81caa707a07a5ace6", null ],
    [ "isca_queue_rd_ptr", "d4/d51/a00017.html#a59547509475e936083586463d4a4430d", null ],
    [ "isca_queue_wr_ptr", "d4/d51/a00017.html#ac487b0939de04c47e01c54342adde2e3", null ]
];