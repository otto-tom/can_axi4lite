var a00051 =
[
    [ "addr", "d2/d79/a00051.html#a78acff4d8c30685792b044c5a236d3d9", null ],
    [ "brp", "d2/d79/a00051.html#acdb1057a12208c5f32f366dc0663dc04", null ],
    [ "tseg1", "d2/d79/a00051.html#a4b49384939516e3271cb04753f123626", null ],
    [ "tseg2", "d2/d79/a00051.html#ab9fc3d3d3f2498e88d2aab03b52cc924", null ],
    [ "sjw", "d2/d79/a00051.html#a6e57e3438c3e525e1658fbe770557571", null ],
    [ "mask", "d2/d79/a00051.html#adc064c1c3f1cd6c5ffd8d5e30303b3cd", null ],
    [ "code", "d2/d79/a00051.html#a0075d5d36f030efedd39bb9f76036ff6", null ],
    [ "q_ptr", "d2/d79/a00051.html#a3d057f9471a44a2b586cc8513e6ad224", null ],
    [ "frm_md", "d2/d79/a00051.html#a6855be8c5ae2b55e0afeec288f132a9e", null ],
    [ "q_id", "d2/d79/a00051.html#a10fe1d80a53c8a74070d141e6e0e5e29", null ],
    [ "q_size", "d2/d79/a00051.html#ac18a13222628c162b3f21001fe7c21de", null ],
    [ "irq", "d2/d79/a00051.html#a0422fe7144094958e2b0bad2d17d8cd9", null ],
    [ "irqs_en", "d2/d79/a00051.html#ab046cc430a26e5223bdee201258524a1", null ],
    [ "InterruptHandler", "d2/d79/a00051.html#af355a8c912b86ba47cdc2b3664e28031", null ]
];