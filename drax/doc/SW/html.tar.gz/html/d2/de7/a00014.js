var a00014 =
[
    [ "ISCA_FPGA_Write8Bit", "d2/de7/a00014.html#a29288f69cd24434f261c69d53874828a", null ],
    [ "ISCA_FPGA_Read8Bit", "d2/de7/a00014.html#a8cccb59a94fd55855a4ac00f96b38be9", null ]
];