var a00047 =
[
    [ "rx", "d6/d2d/a00047.html#ae012c5308e2b6cd2f587189244f052de", null ],
    [ "tx", "d6/d2d/a00047.html#ab1b54f4bddf3b5a84c95572c525e8c1b", null ],
    [ "err0", "d6/d2d/a00047.html#a08c960ecf01b26eea82c7d54281f3ee4", null ],
    [ "err1", "d6/d2d/a00047.html#ad786e7c053549148da131580c92ec715", null ],
    [ "err2", "d6/d2d/a00047.html#a54630a4aa76cc8ddb86bb6e71351f1bb", null ],
    [ "err3", "d6/d2d/a00047.html#af7b7815d83e75422a6008a7e43e56c63", null ],
    [ "err4", "d6/d2d/a00047.html#ae28ae47eada74d403f57dce9bcbec208", null ]
];