var annotated_dup =
[
    [ "can_controller_s", "d2/d79/a00051.html", "d2/d79/a00051" ],
    [ "can_frame_s", "d6/d42/a00043.html", "d6/d42/a00043" ],
    [ "can_irq_en_u", "d6/d2d/a00047.html", "d6/d2d/a00047" ],
    [ "isca_data_queue_indexer", "d4/d6d/a00055.html", "d4/d6d/a00055" ]
];