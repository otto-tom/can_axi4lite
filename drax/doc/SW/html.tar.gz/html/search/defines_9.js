var searchData=
[
  ['rx_5fok',['RX_OK',['../d6/d5b/a00026.html#a5e1c3ca7eba44a7bc9c36275464e8384',1,'ISCA_CAN_IRQ.c']]],
  ['rx_5fqueue_5fsize',['RX_QUEUE_SIZE',['../d4/d8c/a00035.html#a0616225f8714515d1139d62323d2fb60',1,'main.c']]]
];
