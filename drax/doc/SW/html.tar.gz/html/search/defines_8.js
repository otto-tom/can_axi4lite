var searchData=
[
  ['max_5fqueues',['MAX_QUEUES',['../d4/d51/a00017.html#a16d3fa04757c66ba1c3228f57e1be03d',1,'ISCA_QUEUE_INDEXER.h']]]
];
