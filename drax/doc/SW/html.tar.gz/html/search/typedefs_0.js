var searchData=
[
  ['can_5fctrl_5fs',['can_ctrl_s',['../d7/d46/a00002.html#ad7bc4a23ca5adc0601549b615b91a464',1,'ISCA_CAN.h']]],
  ['can_5fframe_5fs',['can_frame_s',['../d7/d46/a00002.html#a35da456ddf6c310110cae4dc6e373a58',1,'ISCA_CAN.h']]]
];
