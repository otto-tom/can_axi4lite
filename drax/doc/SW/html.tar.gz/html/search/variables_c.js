var searchData=
[
  ['wr_5fptr',['wr_ptr',['../d4/d6d/a00055.html#a9bcf5c226a149868e35f98d9f375c103',1,'isca_data_queue_indexer']]]
];
