var searchData=
[
  ['queue_5flock_5facquire',['queue_lock_acquire',['../dc/d87/a00032.html#a9b154efe4bde406048cb21f60db6fc80',1,'ISCA_QUEUE_INDEXER.c']]],
  ['queue_5flock_5frelease',['queue_lock_release',['../dc/d87/a00032.html#a83413b2afd2851d06aaf12b134aea6d8',1,'ISCA_QUEUE_INDEXER.c']]]
];
